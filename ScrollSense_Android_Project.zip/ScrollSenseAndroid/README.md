# ScrollSense — Native Android prototype

This is a native Android Studio project, not a web page. It is designed to count likely Reel changes in Instagram and show a floating badge at the top-right while Instagram is open.

## Build and install
This workspace did not have the Android SDK/Gradle toolchain installed, so it could not produce a ready-to-install APK here. The project source is provided so it can be built with Android Studio.

1. Install Android Studio on a computer.
2. Open this `ScrollSenseAndroid` folder as a project.
3. Let Android Studio sync and install Android SDK Platform 35 if prompted.
4. Connect your Android phone and enable Developer options > USB debugging, or choose Build > Build APK(s) and copy the APK to your phone.
5. Install the APK. If installing manually, Android may ask you to allow installs from that source.

## First-time setup on the phone
1. Open ScrollSense.
2. Tap **Enable accessibility counter**. In Android Accessibility settings, enable **ScrollSense Reel Counter**.
3. Return to ScrollSense and tap **Allow floating counter**. Allow display over other apps.
4. Tap **Start / stop floating badge** until the counter is ON.
5. Open Instagram and go to Reels. A mint badge should appear at the top-right. Tap the badge to pause/resume counting.

## Honest limitations
- This is an early prototype, not a verified BrainPal clone. Instagram does not expose a stable public API for Reel transitions. The service looks for accessible UI changes and Reel-like controls; Instagram updates, accessibility labels, device skins, or language settings can cause missed/double counts.
- It counts only when Instagram is in the foreground and the toggle is enabled.
- It does not capture screenshots, send data to a server, or store video contents.
- Accessibility access is powerful. The service should be enabled only if you understand and accept this permission. All count data is local.
- Android may restrict overlays or accessibility services according to device settings. Test on your own phone.

## Option: build the APK online without installing Android Studio
The project includes `.github/workflows/android.yml` for GitHub Actions.

1. On a computer or phone browser, create a new GitHub repository.
2. Upload the contents of this project to the repository (keep the `.github/workflows/android.yml` file and folder).
3. Open the repository's **Actions** tab and select **Build ScrollSense APK**.
4. Run the workflow with **Run workflow** if it did not start automatically.
5. When it finishes successfully, open that workflow run and download the **ScrollSense-debug-apk** artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installs from your browser or file manager.

A GitHub account is required for this online build route. This workflow is provided because this environment does not have Android SDK/Gradle installed to compile an APK directly here.
