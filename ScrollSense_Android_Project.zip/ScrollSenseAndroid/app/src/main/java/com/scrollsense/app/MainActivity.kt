package com.scrollsense.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(ReelAccessibilityService.PREFS, Context.MODE_PRIVATE) }
    private lateinit var countView: TextView
    private lateinit var statusView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    private fun button(text: String, filled: Boolean = false, action: () -> Unit): TextView =
        label(text, 14f, if (filled) Color.rgb(16,18,27) else Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(if (filled) Color.rgb(140,240,197) else Color.rgb(39,43,61), 14)
            setOnClickListener { action() }
        }
    private fun add(parent: LinearLayout, view: View, top: Int = 0) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (top > 0) lp.topMargin = dp(top)
        parent.addView(view, lp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,18,27)
        window.navigationBarColor = Color.rgb(16,18,27)
        buildUi()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(16,18,27)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(page)
        page.addView(label("◉  SCROLLSENSE", 14f, Color.rgb(140,240,197), true))
        add(page, label("Scroll with\nawareness.", 34f, Color.WHITE, true), 14)
        add(page, label("Your short-video counter", 15f, Color.rgb(166,172,194)), 8)

        val counterCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(22), dp(22), dp(22))
            background = bg(Color.rgb(29,33,49), 24)
        }
        countView = label("0", 72f, Color.rgb(140,240,197), true)
        counterCard.addView(countView)
        counterCard.addView(label("REELS COUNTED TODAY", 12f, Color.rgb(166,172,194), true))
        add(page, counterCard, 24)

        add(page, button("Enable accessibility counter", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find ScrollSense and turn its service on.", Toast.LENGTH_LONG).show()
        }, 18)
        add(page, button("Allow floating counter", false) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Floating counter permission is already enabled.", Toast.LENGTH_SHORT).show()
        }, 10)
        add(page, button("Start / stop floating badge", false) {
            val enabled = !prefs.getBoolean("tracking", false)
            prefs.edit().putBoolean("tracking", enabled).apply()
            sendBroadcast(Intent(ReelAccessibilityService.ACTION_REFRESH).setPackage(packageName))
            refresh()
            Toast.makeText(this, if (enabled) "Counter enabled. Open Instagram Reels." else "Counter paused.", Toast.LENGTH_SHORT).show()
        }, 10)
        add(page, button("Reset today's count", false) {
            prefs.edit().putInt("count", 0).putString("date", ReelAccessibilityService.todayKey()).apply()
            sendBroadcast(Intent(ReelAccessibilityService.ACTION_REFRESH).setPackage(packageName))
            refresh()
        }, 10)

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            background = bg(Color.rgb(29,33,49), 20)
        }
        statusView = label("", 14f, Color.WHITE, true)
        statusCard.addView(statusView)
        statusCard.addView(label("When enabled, a small badge stays at the top-right while you use Instagram. Counts are stored only on this phone.", 13f, Color.rgb(166,172,194)).apply {
            setLineSpacing(dp(4).toFloat(), 1f)
        }.also { it.setPadding(0, dp(8), 0, 0) })
        add(page, statusCard, 20)
        add(page, label("Note: Instagram can change its interface. The counter detects likely Reel transitions, so it may occasionally miss or double-count. It does not read or save video contents.", 12f, Color.rgb(137,144,166)).apply {
            setLineSpacing(dp(3).toFloat(), 1f)
        }, 18)
        setContentView(scroll)
    }

    private fun refresh() {
        val date = ReelAccessibilityService.todayKey()
        if (prefs.getString("date", "") != date) prefs.edit().putString("date", date).putInt("count", 0).apply()
        val count = prefs.getInt("count", 0)
        if (::countView.isInitialized) countView.text = count.toString()
        if (::statusView.isInitialized) {
            val tracking = prefs.getBoolean("tracking", false)
            val overlay = Settings.canDrawOverlays(this)
            statusView.text = (if (tracking) "● Counter is ON" else "○ Counter is paused") +
                "\n" + (if (overlay) "● Floating permission granted" else "○ Floating permission needed") +
                "\n" + (if (isAccessibilityEnabled()) "● Accessibility service enabled" else "○ Accessibility service needed")
            statusView.setTextColor(if (tracking && overlay && isAccessibilityEnabled()) Color.rgb(140,240,197) else Color.rgb(255,200,139))
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${ReelAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, true) || (it.contains(packageName, true) && it.contains("ReelAccessibilityService", true)) }
    }
}
