package com.scrollsense.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReelAccessibilityService : AccessibilityService() {
    companion object {
        const val PREFS = "scrollsense_data"
        const val ACTION_REFRESH = "com.scrollsense.app.REFRESH_BADGE"
        fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private lateinit var wm: WindowManager
    private var badge: TextView? = null
    private var lastFingerprint = ""
    private var lastCountAt = 0L
    private var lastEventAt = 0L
    private var lastScrollY = -1
    private var inInstagram = false
    private var badgeAttached = false

    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateBadgeVisibility(); updateBadgeText() }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter(ACTION_REFRESH)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(refreshReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(refreshReceiver, filter)
        createBadge()
        updateBadgeVisibility()
        updateBadgeText()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getString("date", "") != todayKey()) {
            prefs.edit().putString("date", todayKey()).putInt("count", 0).apply()
        }
        val isInstagram = event.packageName?.toString() == "com.instagram.android"
        if (!isInstagram) {
            inInstagram = false
            lastFingerprint = ""
            updateBadgeVisibility()
            return
        }
        inInstagram = true
        updateBadgeVisibility()
        if (!prefs.getBoolean("tracking", false)) return
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastEventAt < 180) return
        lastEventAt = now

        val root = rootInActiveWindow ?: return
        val fingerprint = buildFingerprint(root)
        val reelLike = looksLikeReel(root, fingerprint)
        if (!reelLike || fingerprint.isBlank()) return

        // Count only when the accessible screen's stable visible labels change, with a debounce.
        // This avoids counting every animation or like-count update.
        if (lastFingerprint.isNotBlank() && fingerprint != lastFingerprint && now - lastCountAt > 1250) {
            val old = prefs.getInt("count", 0)
            prefs.edit().putInt("count", old + 1).putString("date", todayKey()).apply()
            lastCountAt = now
            updateBadgeText()
        }
        lastFingerprint = fingerprint
    }

    private fun buildFingerprint(root: AccessibilityNodeInfo): String {
        val parts = ArrayList<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 12 || parts.size > 100) return
            val text = (node.text?.toString() ?: "").trim()
            val desc = (node.contentDescription?.toString() ?: "").trim()
            // Keep visible semantic labels; skip dynamic counts and long captions.
            listOf(text, desc).forEach { value ->
                if (value.length in 2..65 && !value.matches(Regex("^[0-9,.KkMm]+$")) &&
                    !value.contains("seconds ago", true) && !value.contains("likes", true) &&
                    !value.contains("comments", true) && !value.contains("views", true)) {
                    if (parts.size < 70) parts.add(value.lowercase(Locale.US))
                }
            }
            for (i in 0 until minOf(node.childCount, 20)) walk(node.getChild(i), depth + 1)
        }
        walk(root, 0)
        // Include only a stable sample so transient counters are less likely to trigger.
        val filtered = parts.distinct().filter {
            it !in setOf("home", "search", "create", "reels", "profile", "like", "comment", "share", "send", "more")
        }
        return filtered.take(18).joinToString("|").take(450)
    }

    private fun looksLikeReel(root: AccessibilityNodeInfo, fingerprint: String): Boolean {
        val s = fingerprint.lowercase(Locale.US)
        var hasReelControls = false
        var hasBottomTab = false
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 10) return
            val t = "${n.text ?: ""} ${n.contentDescription ?: ""}".lowercase(Locale.US)
            if (t.contains("like") || t.contains("comment") || t.contains("share") || t.contains("audio") || t.contains("follow")) hasReelControls = true
            if (t == "reels" || t.contains("reels tab")) hasBottomTab = true
            for (i in 0 until minOf(n.childCount, 20)) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        // Reels often expose action controls in accessibility; require several short-video UI clues.
        return hasReelControls && (hasBottomTab || s.contains("original audio") || s.contains("follow"))
    }

    private fun createBadge() {
        if (badge != null) return
        badge = TextView(this).apply {
            text = "🧠 0"
            textSize = 14f
            setTextColor(Color.rgb(16, 18, 27))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = GradientDrawable().apply {
                setColor(Color.rgb(140, 240, 197))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.argb(70, 255, 255, 255))
            }
            elevation = dp(8).toFloat()
            setOnClickListener {
                val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val enabled = !p.getBoolean("tracking", false)
                p.edit().putBoolean("tracking", enabled).apply()
                updateBadgeText()
                updateBadgeVisibility()
            }
        }
    }

    private fun updateBadgeVisibility() {
        if (!::wm.isInitialized || badge == null) return
        val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val shouldShow = p.getBoolean("tracking", false) && inInstagram &&
            android.provider.Settings.canDrawOverlays(this)
        val view = badge!!
        if (shouldShow && !badgeAttached) {
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(12)
                y = dp(95)
            }
            try { wm.addView(view, params); badgeAttached = true } catch (_: Exception) { badgeAttached = false }
        } else if (!shouldShow && badgeAttached) {
            try { wm.removeView(view) } catch (_: Exception) {}
            badgeAttached = false
        }
    }

    private fun updateBadgeText() {
        val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val date = todayKey()
        if (p.getString("date", "") != date) p.edit().putString("date", date).putInt("count", 0).apply()
        badge?.text = "🧠 ${p.getInt("count", 0)}"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onInterrupt() {}
    override fun onDestroy() {
        try { unregisterReceiver(refreshReceiver) } catch (_: Exception) {}
        try { badge?.let { if (it.parent != null) wm.removeView(it) } } catch (_: Exception) {}
        badge = null
        super.onDestroy()
    }
}
